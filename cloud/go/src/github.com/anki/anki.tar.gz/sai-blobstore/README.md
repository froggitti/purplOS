sai-blobstore
=============

An HTTP service for storing and retrieving binary objects with searchable metadata.

Used in dev only for the Cozmo team.
