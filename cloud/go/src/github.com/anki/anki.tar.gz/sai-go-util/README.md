# sai-go-repo

## Overview

```
go get -t github.com/anki/sai-go-util
```

Provides miscellaneous utility packages for use in Anki's Go based applications.

## Testing

```
go test github.com/anki/sai-go-util/...
```
