# DEPRECATED

Usage of this package is deprecated. See
[github.com/anki/sai-awsutil](sai-awsutil) instead.
