# DEPRECATED

Usage of this package is deprecated. Use
[github.com/anki/sai-awsutil/dynamoutil](https://github.com/anki/sai-awsutil/tree/master/dynamoutil)
instead.
