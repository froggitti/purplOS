// package httpcapture captures HTTP requests and responses
// to HAR format, and stores the data either on disk, or in the SAI
// blobstore.
//
// It's intended for development use only and should not be enabled
// in production!
package httpcapture
